package FridgeInsight.FridgeInsight;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.*;

@SpringBootApplication
public class FridgeInsightApplication {
    public static void main(String[] args) {
        SpringApplication.run(FridgeInsightApplication.class, args);
    }
}

