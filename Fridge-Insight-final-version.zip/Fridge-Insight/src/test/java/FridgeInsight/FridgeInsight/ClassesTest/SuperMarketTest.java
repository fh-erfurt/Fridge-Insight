package FridgeInsight.FridgeInsight.ClassesTest;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SuperMarketTest {

    @Test
    void getMarketName() {
    }

    @Test
    void setMarketName() {
    }

    @Test
    void getMarketID() {
    }

    @Test
    void setMarketID() {
    }

    @Test
    void getFoodList() {
    }

    @Test
    void setFoodList() {
    }

    @Test
    void getState() {
    }

    @Test
    void setState() {
    }

    @Test
    void getStreetName() {
    }

    @Test
    void setStreetName() {
    }

    @Test
    void getCity() {
    }

    @Test
    void setCity() {
    }

    @Test
    void getHouseNumber() {
    }

    @Test
    void setHouseNumber() {
    }

    @Test
    void getPostalCode() {
    }

    @Test
    void setPostalCode() {
    }
}