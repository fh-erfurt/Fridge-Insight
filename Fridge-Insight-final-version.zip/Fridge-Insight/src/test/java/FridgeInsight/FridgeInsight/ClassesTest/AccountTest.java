package FridgeInsight.FridgeInsight.ClassesTest;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AccountTest {

    @Test
    void getDateOfCreation() {
    }

    @Test
    void setDateOfCreation() {
    }

    @Test
    void getPassword() {
    }

    @Test
    void setPassword() {
    }

    @Test
    void getACCID() {
    }

    @Test
    void setACCID() {
    }

    @Test
    void isSuperUser() {
    }

    @Test
    void setSuperUser() {
    }

    @Test
    void getPurchaseLists() {
    }

    @Test
    void setPurchaseLists() {
    }

    @Test
    void getFirstName() {
    }

    @Test
    void setFirstName() {
    }

    @Test
    void getLastName() {
    }

    @Test
    void setLastName() {
    }

    @Test
    void getFamilyPosition() {
    }

    @Test
    void setFamilyPosition() {
    }

    @Test
    void getHeight() {
    }

    @Test
    void setHeight() {
    }

    @Test
    void getAge() {
    }

    @Test
    void setAge() {
    }
}