package FridgeInsight.FridgeInsight.ClassesTest;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PurchaseListTest {

    @Test
    void getDateOfPurchase() {
    }

    @Test
    void setDateOfPurchase() {
    }

    @Test
    void getPURCHASEID() {
    }

    @Test
    void setPURCHASEID() {
    }

    @Test
    void getFoods() {
    }

    @Test
    void getAccount() {
    }

    @Test
    void setFoods() {
    }

    @Test
    void setAccount() {
    }
}