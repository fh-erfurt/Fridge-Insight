package FridgeInsight.FridgeInsight.ClassesTest;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FoodTest {

    @Test
    void getFoodTitle() {
    }

    @Test
    void getFoodType() {
    }

    @Test
    void getExpireDate() {
    }

    @Test
    void getFoodQuantity() {
    }

    @Test
    void setExpireDate() {
    }

    @Test
    void setFoodQuantity() {
    }

    @Test
    void setFoodTitle() {
    }

    @Test
    void setFoodType() {
    }

    @Test
    void getFOODID() {
    }

    @Test
    void getNotificationFood() {
    }

    @Test
    void setFOODID() {
    }

    @Test
    void setNotificationFood() {
    }

    @Test
    void getSupermarket() {
    }

    @Test
    void setSupermarket() {
    }

    @Test
    void getPurchaseLists() {
    }

    @Test
    void setPurchaseLists() {
    }

    @Test
    void getFoodUnit() {
    }

    @Test
    void setFoodUnit() {
    }
}