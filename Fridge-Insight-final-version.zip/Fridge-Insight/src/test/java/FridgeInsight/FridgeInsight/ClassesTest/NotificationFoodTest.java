package FridgeInsight.FridgeInsight.ClassesTest;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NotificationFoodTest {

    @Test
    void getMinimumQuantity() {
    }

    @Test
    void setMinimumQuantity() {
    }

    @Test
    void getDateOfExpiration() {
    }

    @Test
    void setDateOfExpiration() {
    }

    @Test
    void getFood() {
    }

    @Test
    void getNOTIFOODID() {
    }

    @Test
    void setFood() {
    }

    @Test
    void setNOTIFOODID() {
    }
}