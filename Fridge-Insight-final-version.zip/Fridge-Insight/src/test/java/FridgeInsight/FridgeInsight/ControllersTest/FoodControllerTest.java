package FridgeInsight.FridgeInsight.ControllersTest;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FoodControllerTest {

    @Test
    void addFood() {
    }

    @Test
    void saveFood() {
    }

    @Test
    void showFoods() {
    }

    @Test
    void deleteFood() {
    }

    @Test
    void updateFood() {
    }
}