package FridgeInsight.FridgeInsight.ControllersTest;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SuperMarketControllerTest {

    @Test
    void saveSuperMarket() {
    }

    @Test
    void addSuperMarket() {
    }

    @Test
    void showSuperMarkets() {
    }

    @Test
    void deleteSuperMarket() {
    }

    @Test
    void showSuperMarketUpdate() {
    }
}