package FridgeInsight.FridgeInsight.ControllersTest;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AccountsControllerTest {

    @Test
    void saveAccount() {

    }

    @Test
    void addAccount() {
    }

    @Test
    void showAccounts() {
    }

    @Test
    void deleteCustomer() {
    }

    @Test
    void showAccountUpdate() {
    }
}