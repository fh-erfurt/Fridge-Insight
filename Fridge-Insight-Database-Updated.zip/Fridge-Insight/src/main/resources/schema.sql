 CREATE TABLE `account` (
  `ACCID` int(11) NOT NULL PRIMARY KEY,
  `dateOfCreation` date NOT NULL,
  `Password` varchar(45) NOT NULL,
  `Person_PersonID` int(11) NOT NULL
);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `address`
--

CREATE TABLE `address` (
  `ADDID` int(11) NOT NULL PRIMARY KEY,
  `houseNumber` varchar(45) NOT NULL,
  `streetName` varchar(45) NOT NULL,
  `City` varchar(45) NOT NULL,
  `State` varchar(45) NOT NULL,
  `postalCode` int(11) NOT NULL
);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `food`
--

CREATE TABLE `food` (
  `FOODID` int(11) NOT NULL PRIMARY KEY ,
  `foodTitle` varchar(45) NOT NULL,
  `expireDate` date NOT NULL,
  `foodQuantity` int(11) NOT NULL,
  `SuperMarket_MARKETID` int(11) NOT NULL
);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `notificationfood`
--

CREATE TABLE `notificationfood` (
  `NOTIFOODID` int(11) NOT NULL PRIMARY KEY ,
  `minimumQuantity` int(11) NOT NULL,
  `dateOfExpiration` date NOT NULL,
  `Food_FOODID` int(11) NOT NULL
);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `person`
--

CREATE TABLE `person` (
  `PersonID` int(11) NOT NULL PRIMARY KEY ,
  `firstName` varchar(45) NOT NULL,
  `lastName` varchar(45) NOT NULL,
  `Age` int(11) NOT NULL,
  `Height` double NOT NULL,
  `superUsr` tinyint(4) NOT NULL,
  `familyPosition` varchar(45) NOT NULL
);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `purchaselist`
--

CREATE TABLE `purchaselist` (
  `PURCHASEID` int(11) NOT NULL PRIMARY KEY ,
  `dateOfPurchase` date NOT NULL,
  `Account_ACCID` int(11) NOT NULL
);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `purchaselist_has_food`
--

CREATE TABLE `purchaselist_has_food` (
  `PURFOODID` int (11) NOT NULL PRIMARY KEY,
  `PurchaseList_PURCHASEID` int(11) NOT NULL,
  `Food_FOODID` int(11) NOT NULL
);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `supermarket`
--

CREATE TABLE `supermarket` (
  `MARKETID` int(11) NOT NULL PRIMARY KEY,
  `marketName` varchar(45) NOT NULL,
  `Address_ADDID` int(11) NOT NULL
);


--
-- Constraints der Tabelle `account`
--
ALTER TABLE `account`
  ADD CONSTRAINT `fk_Account_Person1` FOREIGN KEY (`Person_PersonID`) REFERENCES `person` (`PersonID`);

--
-- Constraints der Tabelle `food`
--
ALTER TABLE `food`
  ADD CONSTRAINT `fk_Food_SuperMarket1` FOREIGN KEY (`SuperMarket_MARKETID`) REFERENCES `supermarket` (`MARKETID`);

--
-- Constraints der Tabelle `notificationfood`
--
ALTER TABLE `notificationfood`
  ADD CONSTRAINT `fk_NotificationFood_Food1` FOREIGN KEY (`Food_FOODID`) REFERENCES `food` (`FOODID`) ;

--
-- Constraints der Tabelle `purchaselist`
--
ALTER TABLE `purchaselist`
  ADD CONSTRAINT `fk_PurchaseList_Account1` FOREIGN KEY (`Account_ACCID`) REFERENCES `account` (`ACCID`) ;

--
-- Constraints der Tabelle `purchaselist_has_food`
--
ALTER TABLE `purchaselist_has_food`
  ADD CONSTRAINT `fk_PurchaseList_has_Food_Food1` FOREIGN KEY (`Food_FOODID`) REFERENCES `food` (`FOODID`);
ALTER TABLE `purchaselist_has_food`
  ADD CONSTRAINT `fk_PurchaseList_has_Food_PurchaseList1` FOREIGN KEY (`PurchaseList_PURCHASEID`) REFERENCES `purchaselist` (`PURCHASEID`) ;

--
-- Constraints der Tabelle `supermarket`
--
ALTER TABLE `supermarket`
  ADD CONSTRAINT `fk_SuperMarket_Address1` FOREIGN KEY (`Address_ADDID`) REFERENCES `address` (`ADDID`);
